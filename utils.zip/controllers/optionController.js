const { option } = require('../models');

module.exports = {
  async getAll(req, res) {
    const data = await option.findAll();
    res.json(data);
  },

  async getById(req, res) {
    const data = await option.findByPk(req.params.id);
    if (!data) return res.status(404).json({ message: 'Option not found' });
    res.json(data);
  },

  async create(req, res) {
    try {
      const data = await option.create(req.body);
      res.status(201).json(data);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  },

  async update(req, res) {
    const data = await option.findByPk(req.params.id);
    if (!data) return res.status(404).json({ message: 'Option not found' });
    await data.update(req.body);
    res.json(data);
  },

  async delete(req, res) {
    const data = await option.findByPk(req.params.id);
    if (!data) return res.status(404).json({ message: 'Option not found' });
    await data.destroy();
    res.json({ message: 'Option deleted' });
  }
};
